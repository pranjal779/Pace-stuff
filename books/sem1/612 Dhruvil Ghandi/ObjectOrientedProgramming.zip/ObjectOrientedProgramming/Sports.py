class Sport:
    # max_score, teams, players
    # __str__
    # __init__

class Football as child of Sports
    # name, score, max_score, teams, players, team_name
    # get_score
    # set_score


class Tennis as child of Sports
    # name, score, max_score, teams, players, player_name, grand_slams
    # set_grand_slams
    # get_grand_slams

